
import React, { useState, useEffect } from 'react';
import { PythonProfile, CalendarEvent } from '../types';
import { predictPythonEvents } from '../services/geminiService';

// A simple hook to persist state to localStorage
const useLocalStorage = <T,>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(error);
    }
  };
  return [storedValue, setValue];
};

const MyCollection: React.FC = () => {
  const [pythons, setPythons] = useLocalStorage<PythonProfile[]>('pythons', []);
  const [selectedPythonId, setSelectedPythonId] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [isLoadingEvents, setIsLoadingEvents] = useState(false);

  const selectedPython = pythons.find(p => p.id === selectedPythonId) || null;

  useEffect(() => {
    if (selectedPython) {
      const fetchEvents = async () => {
        setIsLoadingEvents(true);
        try {
          const predictedEvents = await predictPythonEvents(selectedPython);
          setEvents(predictedEvents);
        } catch (error) {
          console.error("Failed to fetch events:", error);
          setEvents([]);
        } finally {
          setIsLoadingEvents(false);
        }
      };
      fetchEvents();
    }
  }, [selectedPythonId]);
  
  const handleAddPython = (python: PythonProfile) => {
    setPythons(prev => [...prev, { ...python, id: Date.now().toString() }]);
    setIsAdding(false);
  };
  
  const handleDeletePython = (id: string) => {
    if (window.confirm("Sei sicuro di voler eliminare questo pitone dalla tua collezione?")) {
      setPythons(pythons.filter(p => p.id !== id));
      setSelectedPythonId(null);
    }
  }

  const handleUpdatePython = (updatedPython: PythonProfile) => {
    setPythons(prev => prev.map(p => p.id === updatedPython.id ? updatedPython : p));
  };

  if (selectedPython) {
    return (
      <PythonDetailView 
        python={selectedPython} 
        events={events} 
        isLoading={isLoadingEvents} 
        onBack={() => setSelectedPythonId(null)} 
        onDelete={handleDeletePython}
        onUpdate={handleUpdatePython}
      />
    );
  }

  if (isAdding) {
    return <AddPythonForm onAdd={handleAddPython} onCancel={() => setIsAdding(false)} />;
  }

  return (
    <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8 md:py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10">
        <div>
          <h2 className="text-4xl font-black text-white">La Mia Collezione</h2>
          <p className="text-slate-500 mt-1">Gestisci e monitora i tuoi esemplari.</p>
        </div>
        <button onClick={() => setIsAdding(true)} className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-6 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/20">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
          Nuovo Esemplare
        </button>
      </div>
      
      {pythons.length === 0 ? (
        <div className="text-center py-24 border-2 border-dashed border-slate-700 rounded-[2rem] bg-slate-800/20">
            <svg className="mx-auto h-20 w-20 text-slate-700 mb-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 0h-4m4 0l-5-5" /></svg>
            <h3 className="text-2xl font-bold text-slate-400">Nessun pitone registrato</h3>
            <p className="mt-2 text-slate-500 max-w-sm mx-auto">Aggiungi i tuoi animali per tenere traccia di pasti, mute e ricevere consigli dall'AI.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pythons.map(python => (
                <div 
                  key={python.id} 
                  onClick={() => setSelectedPythonId(python.id)} 
                  className="bg-slate-800/40 p-6 rounded-3xl border border-slate-700/50 hover:border-emerald-500/50 hover:bg-slate-800/60 cursor-pointer transition-all group relative overflow-hidden"
                >
                    <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <svg className="w-5 h-5 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                    </div>
                    <h3 className="text-2xl font-bold text-white truncate group-hover:text-emerald-400 transition-colors">{python.name}</h3>
                    <p className="text-slate-400 font-medium mb-4 text-sm uppercase tracking-wider">{python.morph}</p>
                    <div className="grid grid-cols-2 gap-4 text-xs border-t border-slate-700/50 pt-4 mt-2">
                        <div className="flex flex-col">
                          <span className="text-slate-500 uppercase font-bold tracking-tighter">Peso</span>
                          <span className="text-slate-200 font-bold">{python.weight}g</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-slate-500 uppercase font-bold tracking-tighter">Sesso</span>
                          <span className="text-slate-200 font-bold">{python.sex}</span>
                        </div>
                    </div>
                </div>
            ))}
        </div>
      )}
    </main>
  );
};

const AddPythonForm: React.FC<{ onAdd: (python: PythonProfile) => void; onCancel: () => void; }> = ({ onAdd, onCancel }) => {
    const [formData, setFormData] = useState({ 
      name: '', 
      morph: '', 
      birthDate: '', 
      weight: '', 
      sex: 'Unknown' as PythonProfile['sex'], 
      lastFed: '', 
      lastShed: '' 
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onAdd({ 
            ...formData, 
            weight: parseInt(formData.weight) || 0, 
            id: '',
            lastFed: formData.lastFed ? [formData.lastFed] : [],
            lastShed: formData.lastShed ? [formData.lastShed] : []
        });
    }

    return (
        <main className="flex-1 max-w-2xl mx-auto w-full px-4 py-8 md:py-12 animate-in fade-in slide-in-from-bottom-4">
            <div className="flex items-center gap-4 mb-8">
              <button onClick={onCancel} className="p-2 text-slate-500 hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
              </button>
              <h2 className="text-4xl font-black text-white">Nuovo Esemplare</h2>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6 bg-slate-800/30 p-8 rounded-[2.5rem] border border-slate-700/50 shadow-2xl backdrop-blur-xl">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest block mb-2">Nome</label>
                        <input type="text" name="name" placeholder="Es: Monty" onChange={handleChange} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white focus:border-emerald-500 outline-none transition-colors" required />
                    </div>
                     <div>
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest block mb-2">Morph</label>
                        <input type="text" name="morph" placeholder="Es: Banana Pastel Pied" onChange={handleChange} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white focus:border-emerald-500 outline-none transition-colors" required />
                    </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div>
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest block mb-2">Data di Nascita</label>
                        <input type="date" name="birthDate" onChange={handleChange} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white focus:border-emerald-500 outline-none transition-colors" required />
                    </div>
                    <div>
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest block mb-2">Sesso</label>
                        <select name="sex" onChange={handleChange} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white focus:border-emerald-500 outline-none transition-colors">
                            <option value="Unknown">Unknown</option>
                            <option value="Male">Maschio</option>
                            <option value="Female">Femmina</option>
                        </select>
                    </div>
                </div>
                
                <div>
                    <label className="text-xs font-black text-slate-500 uppercase tracking-widest block mb-2">Peso Attuale (grammi)</label>
                    <input type="number" name="weight" placeholder="0" onChange={handleChange} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white focus:border-emerald-500 outline-none transition-colors" required />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-700/50">
                     <div>
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest block mb-2">Ultimo Pasto</label>
                        <input type="date" name="lastFed" onChange={handleChange} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white focus:border-emerald-500 outline-none transition-colors" required />
                    </div>
                     <div>
                        <label className="text-xs font-black text-slate-500 uppercase tracking-widest block mb-2">Ultima Muta</label>
                        <input type="date" name="lastShed" onChange={handleChange} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white focus:border-emerald-500 outline-none transition-colors" required />
                    </div>
                </div>
                
                <div className="flex gap-4 pt-4">
                    <button type="submit" className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 uppercase tracking-widest text-sm">Salva Esemplare</button>
                    <button type="button" onClick={onCancel} className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-black py-4 rounded-2xl transition-all uppercase tracking-widest text-sm">Annulla</button>
                </div>
            </form>
        </main>
    );
};

const PythonDetailView: React.FC<{ 
  python: PythonProfile; 
  events: CalendarEvent[]; 
  isLoading: boolean; 
  onBack: () => void; 
  onDelete: (id: string) => void;
  onUpdate: (updated: PythonProfile) => void;
}> = ({ python, events, isLoading, onBack, onDelete, onUpdate }) => {
  
  const addEvent = (type: 'lastFed' | 'lastShed') => {
    const date = new Date().toISOString().split('T')[0];
    const updated = {
      ...python,
      [type]: [date, ...(python[type] || [])].slice(0, 10) // Keep last 10
    };
    onUpdate(updated);
  };

  const updateWeight = () => {
    const newWeight = prompt("Inserisci il nuovo peso (g):", python.weight.toString());
    if (newWeight && !isNaN(parseInt(newWeight))) {
      onUpdate({ ...python, weight: parseInt(newWeight) });
    }
  };

  return (
    <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8 md:py-12 animate-in fade-in slide-in-from-bottom-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 text-slate-500 hover:text-white transition-colors bg-slate-800/50 rounded-full">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          </button>
          <div>
            <h2 className="text-5xl font-black text-white">{python.name}</h2>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-emerald-400 font-bold text-sm uppercase tracking-widest">{python.morph}</span>
              <span className="text-slate-700">•</span>
              <span className="text-slate-500 text-sm font-medium">{python.sex}</span>
            </div>
          </div>
        </div>
        <button 
          onClick={() => onDelete(python.id)} 
          className="text-red-500 hover:text-red-400 text-xs font-black uppercase tracking-widest px-4 py-2 border border-red-500/20 rounded-lg hover:bg-red-500/5 transition-all"
        >
          Elimina Esemplare
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Stats & Actions */}
        <div className="lg:col-span-2 space-y-8">
          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div className="bg-slate-800/40 p-6 rounded-3xl border border-slate-700/50">
              <div className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Peso Attuale</div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-black text-white">{python.weight}g</span>
                <button onClick={updateWeight} className="mb-1 text-emerald-500 hover:text-emerald-400">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                </button>
              </div>
            </div>
            <div className="bg-slate-800/40 p-6 rounded-3xl border border-slate-700/50">
              <div className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Ultimo Pasto</div>
              <div className="text-xl font-bold text-white">{python.lastFed[0] || 'Mai'}</div>
            </div>
            <div className="bg-slate-800/40 p-6 rounded-3xl border border-slate-700/50">
              <div className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Nato il</div>
              <div className="text-xl font-bold text-white">{python.birthDate}</div>
            </div>
          </div>

          {/* Action Log Buttons */}
          <div className="flex flex-wrap gap-4">
            <button 
              onClick={() => addEvent('lastFed')}
              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-4 px-6 rounded-2xl transition-all shadow-lg shadow-emerald-500/10 flex items-center justify-center gap-3"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
              Log Pasto Oggi
            </button>
            <button 
              onClick={() => addEvent('lastShed')}
              className="flex-1 bg-blue-500 hover:bg-blue-600 text-white font-bold py-4 px-6 rounded-2xl transition-all shadow-lg shadow-blue-500/10 flex items-center justify-center gap-3"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
              Log Muta Oggi
            </button>
          </div>

          {/* History Lists */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-slate-800/20 p-8 rounded-[2rem] border border-slate-700/30">
              <h3 className="text-xs font-black text-emerald-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                Cronologia Pasti
              </h3>
              <div className="space-y-4">
                {python.lastFed.map((date, i) => (
                  <div key={i} className="flex justify-between items-center py-2 border-b border-slate-700/30 text-sm">
                    <span className="text-slate-300 font-medium">{date}</span>
                    <span className="text-slate-600 text-[10px] font-bold uppercase">Successo</span>
                  </div>
                ))}
                {python.lastFed.length === 0 && <p className="text-slate-600 text-xs">Nessun pasto registrato.</p>}
              </div>
            </div>
            
            <div className="bg-slate-800/20 p-8 rounded-[2rem] border border-slate-700/30">
              <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                Cronologia Mute
              </h3>
              <div className="space-y-4">
                {python.lastShed.map((date, i) => (
                  <div key={i} className="flex justify-between items-center py-2 border-b border-slate-700/30 text-sm">
                    <span className="text-slate-300 font-medium">{date}</span>
                    <span className="text-slate-600 text-[10px] font-bold uppercase">Muta Completa</span>
                  </div>
                ))}
                {python.lastShed.length === 0 && <p className="text-slate-600 text-xs">Nessuna muta registrata.</p>}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: AI Predictions */}
        <div className="space-y-8">
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 p-8 rounded-[2.5rem] shadow-2xl sticky top-24">
            <h3 className="text-xs font-black text-emerald-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              Smart Predictions AI
            </h3>

            {isLoading ? (
              <div className="py-12 flex flex-col items-center gap-4 text-center">
                <div className="w-8 h-8 border-2 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" />
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest animate-pulse">Analisi Bio-ciclo...</p>
              </div>
            ) : (
              <div className="space-y-6">
                {events.length > 0 ? events.map((ev, i) => (
                  <div key={i} className="group">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-sm font-black text-white uppercase tracking-tighter">{ev.event}</span>
                      <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">{ev.predictedDate}</span>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed group-hover:text-slate-400 transition-colors">
                      {ev.justification}
                    </p>
                    {i < events.length - 1 && <div className="mt-6 border-t border-slate-700/50" />}
                  </div>
                )) : (
                  <p className="text-slate-600 text-xs italic">Nessuna previsione disponibile al momento.</p>
                )}
                
                <div className="mt-8 p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                  <p className="text-[10px] text-slate-500 font-medium text-center leading-relaxed">
                    Le previsioni sono generate algoritmicamente basandosi sui cicli tipici della specie e sui dati storici del tuo esemplare.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
};

export default MyCollection;

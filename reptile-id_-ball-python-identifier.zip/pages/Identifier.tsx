
import React, { useState } from 'react';
import ImageUploader from '../components/ImageUploader';
import AnalysisResult from '../components/AnalysisResult';
import { analyzeMorph } from '../services/geminiService';
import { AnalysisImage, MorphAnalysis } from '../types';

const Identifier: React.FC = () => {
  const [images, setImages] = useState<AnalysisImage[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<MorphAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isQuotaError, setIsQuotaError] = useState(false);
  const [progressText, setProgressText] = useState("Inizializzazione Core...");

  const handleStartAnalysis = async () => {
    if (images.length === 0) {
      setError("Carica almeno un'immagine ad alta risoluzione per procedere.");
      return;
    }
    
    setIsAnalyzing(true);
    setError(null);
    setIsQuotaError(false);
    setResult(null);

    const steps = [
      "Mappatura Pattern Dorsale...",
      "Analisi Distribuzione Melanina...",
      "Verifica Marcatori Recessivi...",
      "Cross-referencing Database Globale...",
      "Generazione Referto Tecnico..."
    ];

    let i = 0;
    const interval = setInterval(() => {
      if (i < steps.length) setProgressText(steps[i++]);
    }, 1500);

    try {
      const analysis = await analyzeMorph(images);
      if (!analysis || !analysis.name) {
        throw new Error("Dati ricevuti incompleti. Riprova.");
      }
      setResult(analysis);
    } catch (err: any) {
      console.error("[Identifier] Analisi fallita:", err);
      const msg = err.message || "";
      if (msg.includes("QUOTA_EXCEEDED") || msg.includes("429")) {
        setIsQuotaError(true);
        setError("Quota API Esaurita. Se hai un abbonamento Pro, verifica i limiti RPM nella console di Google Cloud.");
      } else {
        setError(msg || "Il sistema non è riuscito a isolare i geni. Riprova con foto più nitide e senza riflessi.");
      }
    } finally {
      clearInterval(interval);
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setImages([]);
    setResult(null);
    setError(null);
    setIsQuotaError(false);
  };

  return (
    <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8 md:py-16">
      {!result && !isAnalyzing && (
        <div className="text-center mb-20 animate-in fade-in slide-in-from-top-4 duration-700">
          <div className="inline-block mb-4 px-6 py-2 rounded-full bg-slate-800 border border-slate-700 shadow-xl">
            <span className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.5em]">Identificazione Pro v2.0</span>
          </div>
          <h2 className="text-6xl md:text-8xl font-black mb-8 tracking-tighter text-white leading-none">
            La Scienza dei <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-400 to-indigo-500">Morph Perfetti.</span>
          </h2>
          <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto font-medium leading-relaxed mb-12">
            Utilizziamo una rete neurale specializzata nell'erpetologia per mappare ogni singola variazione cromatica del tuo pitone reale.
          </p>
        </div>
      )}

      {error ? (
        <div className="max-w-xl mx-auto bg-slate-800/50 border border-slate-700/50 rounded-[3rem] p-12 text-center backdrop-blur-3xl shadow-2xl">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-8 ${isQuotaError ? 'bg-amber-500/10' : 'bg-red-500/10'}`}>
            <svg className={`w-10 h-10 ${isQuotaError ? 'text-amber-500' : 'text-red-500'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <p className={`${isQuotaError ? 'text-amber-400' : 'text-red-400'} mb-6 font-black text-2xl uppercase tracking-tighter`}>{isQuotaError ? 'Limite Quota Raggiunto' : 'Analisi Fallita'}</p>
          <p className="text-slate-400 text-sm mb-10 leading-relaxed">{error}</p>
          
          <div className="flex flex-col gap-4">
            <button onClick={handleStartAnalysis} className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-black py-5 px-8 rounded-2xl transition-all uppercase tracking-[0.2em] text-xs shadow-lg shadow-emerald-500/20">Riprova Analisi</button>
            {isQuotaError && (
              <a 
                href="https://console.cloud.google.com/apis/enabled" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full bg-slate-700 hover:bg-slate-600 text-white font-black py-5 px-8 rounded-2xl transition-all uppercase tracking-[0.2em] text-xs text-center border border-slate-600"
              >
                Aumenta Limiti in Google Cloud
              </a>
            )}
            <button onClick={reset} className="w-full bg-slate-900 hover:bg-slate-800 text-slate-500 font-black py-3 px-8 rounded-2xl transition-all uppercase tracking-[0.2em] text-[10px]">Annulla e Ricomincia</button>
          </div>
        </div>
      ) : result ? (
        <div className="max-w-5xl mx-auto space-y-10">
          <button onClick={reset} className="flex items-center gap-4 text-slate-500 hover:text-emerald-400 transition-all font-black text-[10px] uppercase tracking-[0.4em] group">
            <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            Nuova Scansione Genomica
          </button>
          <AnalysisResult result={result} />
        </div>
      ) : (
        <div className="max-w-5xl mx-auto bg-slate-800/20 backdrop-blur-2xl border border-slate-700/50 rounded-[4rem] p-8 md:p-16 shadow-2xl relative">
          <div className="absolute top-8 left-8">
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-900/80 rounded-full border border-slate-700">
               <div className={`w-2 h-2 rounded-full ${isAnalyzing ? 'bg-amber-500 animate-ping' : 'bg-emerald-500 animate-pulse'}`} />
               <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{isAnalyzing ? 'Elaborazione in corso' : 'Analizzatore Attivo'}</span>
            </div>
          </div>

          <div className="mb-12 text-center space-y-3">
            <h3 className="text-3xl font-black text-white uppercase tracking-tight">Acquisizione Dati</h3>
            <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Fornisci angolazioni multiple per massimizzare la precisione</p>
          </div>
          
          <ImageUploader onImagesChange={setImages} images={images} disabled={isAnalyzing} />
          
          <div className="mt-16 flex flex-col items-center">
            <button
              disabled={images.length < 1 || isAnalyzing}
              onClick={handleStartAnalysis}
              className={`
                relative overflow-hidden group py-7 px-20 rounded-[2rem] font-black text-xs uppercase tracking-[0.5em] transition-all
                ${images.length >= 1 && !isAnalyzing
                  ? 'bg-emerald-500 text-white shadow-[0_20px_40px_rgba(16,185,129,0.3)] hover:scale-105 active:scale-95' 
                  : 'bg-slate-700 text-slate-500 cursor-not-allowed'}
              `}
            >
              <span className="relative z-10 flex items-center gap-3">
                {isAnalyzing && (
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                )}
                {isAnalyzing ? 'Analisi in Corso...' : 'Processa Esemplare'}
              </span>
              {!isAnalyzing && <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-500 opacity-0 group-hover:opacity-100 transition-opacity" />}
            </button>
            
            {isAnalyzing && (
              <div className="mt-8 text-center space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <p className="text-emerald-400 font-black text-[10px] uppercase tracking-[0.2em] animate-pulse">{progressText}</p>
                <div className="w-64 h-1 bg-slate-800 rounded-full overflow-hidden mx-auto">
                  <div className="h-full bg-emerald-500 animate-[loading_2s_ease-in-out_infinite]" />
                </div>
              </div>
            )}
            
            {!isAnalyzing && (
              <div className="mt-10 flex gap-8">
                 {['head', 'body', 'belly'].map((part) => (
                   <div key={part} className="flex flex-col items-center gap-2">
                      <div className={`w-1.5 h-1.5 rounded-full transition-colors duration-500 ${images.some(i => i.part === part) ? 'bg-emerald-500' : 'bg-slate-800'}`} />
                      <span className={`text-[9px] font-black uppercase tracking-widest ${images.some(i => i.part === part) ? 'text-slate-300' : 'text-slate-700'}`}>{part}</span>
                   </div>
                 ))}
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  );
};

export default Identifier;


import React, { useState, useEffect, useRef } from 'react';
import { searchMorphDatabase } from '../services/geminiService';
import { MorphDatabaseEntry } from '../types';

const MorphDatabase: React.FC = () => {
  const [search, setSearch] = useState('');
  const [morphs, setMorphs] = useState<MorphDatabaseEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('Tutti');
  const initialLoadRef = useRef(false);

  const categories = ['Tutti', 'Base', 'Combo', 'Recessivi', 'Novità'];

  const performSearch = async (query: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const results = await searchMorphDatabase(query);
      setMorphs(results);
    } catch (err: any) {
      console.error(err);
      if (err?.message?.includes('QUOTA_EXCEEDED')) {
        setError("Limite richieste raggiunto. Riprova tra un minuto.");
      } else {
        setError("Errore nella ricerca live. Controlla la connessione.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!initialLoadRef.current) {
      performSearch('');
      initialLoadRef.current = true;
    }
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveCategory('Tutti');
    performSearch(search);
  };

  return (
    <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8 md:py-16">
      <div className="text-center mb-16 space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-widest">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          Ricerca Granulare Attiva (Grounding)
        </div>
        <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter">
          Morph <span className="text-emerald-500">Explorer</span>
        </h2>
        <p className="text-slate-400 max-w-2xl mx-auto text-lg font-medium">
          Cerca un gene specifico (es. Acid, Clown, Pied) per visualizzare tutte le combo correlate e le schede aggiornate su MorphMarket.
        </p>
      </div>

      <div className="mb-12">
        <form onSubmit={handleSearchSubmit} className="max-w-3xl mx-auto relative group">
          <input 
            type="text" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cerca un gene o una combo (es: Acid, Rainbow, Stranger)..."
            className="w-full bg-slate-800/50 border-2 border-slate-700 rounded-[2rem] py-6 px-10 text-white text-lg focus:border-emerald-500 outline-none transition-all pr-32 backdrop-blur-xl shadow-2xl"
          />
          <button 
            type="submit"
            disabled={isLoading}
            className="absolute right-3 top-3 bottom-3 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-700 text-white px-8 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg"
          >
            {isLoading ? '...' : 'Cerca'}
          </button>
        </form>

        <div className="flex flex-wrap justify-center gap-3 mt-8">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => {
                setActiveCategory(cat);
                setSearch('');
                performSearch(cat === 'Tutti' ? '' : cat);
              }}
              className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${
                activeCategory === cat 
                ? 'bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                : 'border-slate-700 text-slate-500 hover:border-slate-500'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="max-w-3xl mx-auto mb-12 p-6 bg-red-500/10 border border-red-500/20 rounded-2xl text-center text-red-400 font-bold text-sm">
          {error}
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="bg-slate-800/20 border border-slate-700 h-[30rem] rounded-[2.5rem] animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {morphs.map((morph, idx) => (
            <div 
              key={idx} 
              className="bg-slate-800/30 border border-slate-700/50 rounded-[2.5rem] hover:bg-slate-800/50 transition-all group hover:border-emerald-500/30 overflow-hidden flex flex-col relative animate-in fade-in slide-in-from-bottom-4 duration-500"
            >
              <div className="absolute top-4 right-4 z-20">
                <span className="bg-emerald-500 text-white text-[8px] font-black px-2 py-1 rounded-md uppercase tracking-widest shadow-lg">Live Link</span>
              </div>

              <div className="relative h-56 bg-slate-900 flex items-center justify-center overflow-hidden border-b border-slate-700/50">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent opacity-60" />
                <div className="p-8 text-center space-y-4 relative z-10">
                   <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                     <svg className="w-7 h-7 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                     </svg>
                   </div>
                   {morph.imageUrl ? (
                     <a 
                      href={morph.imageUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-block bg-emerald-500 hover:bg-emerald-600 text-white text-[11px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/30 hover:-translate-y-1 active:scale-95"
                     >
                       Apri Gallery Real-Time
                     </a>
                   ) : (
                     <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Generazione link...</p>
                   )}
                </div>
                <div className="absolute bottom-4 left-4">
                   <span className="bg-emerald-500/20 backdrop-blur-md px-3 py-1 rounded-full text-[9px] font-black text-emerald-400 uppercase border border-emerald-500/20">{morph.complexity}</span>
                </div>
              </div>

              <div className="p-8 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-2 gap-4">
                  <h3 className="text-2xl font-black text-white group-hover:text-emerald-400 transition-colors tracking-tight leading-tight">
                    {morph.name}
                  </h3>
                  <span className="text-[10px] font-bold text-slate-500 bg-slate-900 px-2 py-0.5 rounded shrink-0 border border-slate-700">{morph.rarity}</span>
                </div>
                <p className="text-emerald-500/70 text-xs font-bold uppercase tracking-widest mb-4">{morph.genetics}</p>
                <p className="text-slate-400 text-sm leading-relaxed mb-6 line-clamp-4 font-medium">
                  {morph.description}
                </p>
                
                <div className="mt-auto flex flex-wrap gap-2 pt-4 border-t border-slate-700/50">
                  {morph.tags.slice(0, 3).map(tag => (
                    <span key={tag} className="text-[9px] font-black text-slate-500 uppercase bg-slate-900/50 px-3 py-1.5 rounded-lg border border-slate-700/50">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {!isLoading && !error && morphs.length === 0 && (
        <div className="text-center py-32 bg-slate-800/10 rounded-[4rem] border border-dashed border-slate-700 max-w-2xl mx-auto backdrop-blur-xl">
           <div className="w-20 h-20 bg-slate-900 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-slate-700">
             <svg className="w-10 h-10 text-slate-700" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
           </div>
           <p className="text-slate-500 font-bold uppercase tracking-[0.3em] px-8">Inizia una ricerca granulare per esplorare i Morph mondiali</p>
        </div>
      )}
    </main>
  );
};

export default MorphDatabase;

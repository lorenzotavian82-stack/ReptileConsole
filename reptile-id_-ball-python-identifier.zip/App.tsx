
import React, { useState } from 'react';
import Header from './components/Header';
import Identifier from './pages/Identifier';
import MyCollection from './pages/MyCollection';
import MorphDatabase from './pages/MorphDatabase';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<'identifier' | 'collection' | 'database'>('identifier');

  return (
    <div className="min-h-screen flex flex-col selection:bg-emerald-500 selection:text-white">
      <Header currentPage={currentPage} onNavigate={setCurrentPage} />
      
      {currentPage === 'identifier' && <Identifier />}
      {currentPage === 'database' && <MorphDatabase />}
      {currentPage === 'collection' && <MyCollection />}

      <footer className="border-t border-slate-800 py-12 text-center bg-slate-900/80 backdrop-blur-md mt-auto">
        <p className="text-slate-600 text-[10px] font-black uppercase tracking-[0.5em] mb-4">Reptile ID System</p>
        <div className="space-y-2">
            <p className="text-slate-700 text-[10px] max-w-md mx-auto px-4">Questo sistema è inteso come supporto decisionale. Consultare sempre un esperto per conferme ufficiali.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;

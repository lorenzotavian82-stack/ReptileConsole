
import { GoogleGenAI, Type } from "@google/genai";
import { MorphAnalysis, AnalysisImage, PythonProfile, CalendarEvent, MorphDatabaseEntry } from "../types";

// Funzione per pulire il testo di Gemini che spesso include ```json ... ```
const cleanJsonString = (text: string): string => {
  if (!text) return "";
  return text.replace(/```json/g, '').replace(/```/g, '').trim();
};

// Funzione helper per gestire i retry in caso di errore di quota (429)
async function withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 2000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const errorMsg = error?.message?.toLowerCase() || "";
    const isQuotaError = errorMsg.includes('429') || errorMsg.includes('quota') || errorMsg.includes('resource_exhausted');
    
    if (isQuotaError && retries > 0) {
      console.warn(`[GeminiService] Quota raggiunta. Tentativo di recupero in ${delay}ms... (${retries} rimasti)`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(fn, retries - 1, delay * 2);
    }
    
    if (isQuotaError) {
      throw new Error("QUOTA_EXCEEDED: Hai esaurito le richieste disponibili per questo minuto. Riprova tra poco.");
    }
    
    throw error;
  }
}

export const searchMorphDatabase = async (query: string): Promise<MorphDatabaseEntry[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return withRetry(async () => {
    // Usiamo gemini-3-flash-preview per Search Grounding veloce e filtraggio preciso
    const model = 'gemini-3-flash-preview';
    const isSpecificSearch = query && query.trim() !== '' && query.toLowerCase() !== 'tutti' && query.toLowerCase() !== 'novità';
    
    const prompt = isSpecificSearch 
      ? `CERCA RIGOROSAMENTE SOLO morph che contengano il gene "${query}". Restituisci una lista di morph base e combo (es. ${query} Clown, ${query} Pastel, ecc.). 
         Ogni risultato DEVE avere "${query}" nel nome o nella genetica. 
         Per ogni morph, genera un link MorphMarket: https://www.morphmarket.com/us/c/reptiles/pythons/ball-pythons?q=[NOME_MORPH_CODIFICATO]`
      : `Trova le schede dei morph di pitone reale più popolari e recenti (Novità 2024/2025). 
         Fornisci link diretti alla ricerca MorphMarket per ogni esemplare.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: `Sei un esperto di genetica dei pitoni reali e moderatore di MorphMarket. 
        Se l'utente fornisce un termine di ricerca, devi restituire ESCLUSIVAMENTE morph pertinenti a quel termine. 
        Esempio: se cerco "Acid", restituisci "Acid", "Acid Clown", "Acid Pied", ecc. 
        Non restituire morph non correlati. Restituisci i dati in un array JSON.`,
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              genetics: { type: Type.STRING },
              description: { type: Type.STRING },
              complexity: { type: Type.STRING, enum: ['Base', 'Combo', 'Complex'] },
              rarity: { type: Type.STRING },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } },
              imageUrl: { type: Type.STRING, description: "URL di ricerca MorphMarket per questo specifico morph" }
            },
            required: ["name", "genetics", "description", "complexity", "rarity", "tags", "imageUrl"]
          }
        }
      }
    });

    try {
      const text = cleanJsonString(response.text || "[]");
      let results: MorphDatabaseEntry[] = JSON.parse(text);
      
      // Assicuriamoci che i link siano corretti e puntino a MorphMarket
      results = results.map(res => {
        const encoded = encodeURIComponent(res.name);
        res.imageUrl = `https://www.morphmarket.com/us/c/reptiles/pythons/ball-pythons?q=${encoded}`;
        return res;
      });

      return results;
    } catch (e) {
      console.error("[GeminiService] Errore parsing Database:", e);
      return [];
    }
  });
};

export const analyzeMorph = async (images: AnalysisImage[]): Promise<MorphAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return withRetry(async () => {
    // Utilizziamo Gemini 3 Pro con Thinking Mode (budget 32768) per un'analisi approfondita delle immagini
    const model = 'gemini-3-pro-preview';
    const imageParts = images.map(img => ({
      inlineData: { mimeType: 'image/jpeg', data: img.data.split(',')[1] }
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash-thinking-exp-01-21',
      contents: {
        parts: [
          ...imageParts,
          { text: `Esegui un'analisi bio-genetica ESTREMAMENTE dettagliata su queste foto di Pitone Reale (Ball Python).
Il tuo obiettivo è identificare con precisione assoluta la combinazione genetica completa (Morph Combo), inclusi i geni recessivi, codominanti e dominanti.

CRITICO: Questo sistema deve rilevare combo complesse (3, 4, 5 o più geni).
Non fermarti ai geni ovvi. Devi de-costruire il fenotipo per trovare ogni singolo gene che contribuisce all'aspetto finale.
Se un animale ha 5 geni (es. "Pastel Enchi Yellow Belly Fire Clown"), devi elencarli TUTTI e 5.
Analizza la "sovrapposizione dei pattern" (Pattern Stacking): come un gene modifica l'altro.

IMPORTANTE:
1. Cerca geni "enhancer" o "cleaner" che spesso sono presenti in combo (Fire, Vanilla, Yellow Belly, OD, Enchi).
2. Identifica anche i possibili geni "Het" (Eterozigoti) se ci sono marker visivi.
3. Se l'animale è una combo complessa, elenca TUTTI i componenti nel nome.

Analizza pixel per pixel:
1. Testa (Headstamp): Cerca pattern specifici, blushing, scolorimenti, occhi.
2. Corpo (Body): Analizza alien heads, colore di fondo, flaming, blushing, ringing, granite style.
3. Ventre (Belly): Cerca tracks, assenza di pattern, o colorazioni specifiche.

Rispondi SOLO in JSON seguendo lo schema.` }
        ]
      },
      config: {
        systemInstruction: `Sei il più grande esperto mondiale di genetica dei Pitoni Reali (Ball Pythons). 
        Hai una capacità sovrumana di riconoscere morph e combo complesse da foto, anche quando i tratti sono sottili.
        Conosci a memoria ogni marker visivo per migliaia di geni: recessivi (Clown, Pied, Ghost, ecc.), dominanti/codominanti (Pastel, Enchi, Fire, OD, YB, ecc.).
        Il tuo compito è fornire l'identificazione più accurata possibile, scovando anche i geni "invisibili" ai meno esperti e i tratti eterozigoti (Het) quando manifestano marker visivi.`,
        thinkingConfig: { thinkingBudget: 32768 },
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING, description: "Il nome completo della combo identificata (es. 'Mojave Pastel Het Clown Ball Python')" },
            confidence: { type: Type.NUMBER, description: "Livello di confidenza da 0 a 100" },
            description: { type: Type.STRING, description: "Descrizione dettagliata del perché è stata identificata questa combo, menzionando specificamente ogni gene trovato." },
            geneticAnalysis: { type: Type.STRING, description: "Spiegazione tecnica dei marker genetici trovati per OGNI gene, inclusi i Het." },
            rarity: { type: Type.STRING },
            typicalAppearance: { type: Type.STRING, description: "Descrizione dell'aspetto tipico di questo morph o combo (es. 'Solitamente presenta pattern ridotto e colori più brillanti...')" },
            isCombo: { type: Type.BOOLEAN },
            geneticLikelihood: { type: Type.STRING, description: "Probabilità genetica e possibili alleli (es. 'Visual Recessive', 'Het', 'Co-Dom')" },
            traits: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  category: { type: Type.STRING, description: "Parte del corpo (Testa, Corpo, Ventre)" },
                  details: { type: Type.STRING, description: "Dettaglio specifico (es. 'Headstamp sbiadito', 'Ventre pulito')" },
                  foundIn: { type: Type.STRING, description: "Gene associato a questo tratto (es. 'Pastel', 'Het Clown')" }
                },
                required: ["category", "details", "foundIn"]
              }
            }
          },
          required: ["name", "confidence", "description", "geneticAnalysis", "traits", "rarity", "isCombo", "geneticLikelihood"]
        }
      }
    });

    try {
      const cleaned = cleanJsonString(response.text || "{}");
      const result = JSON.parse(cleaned) as MorphAnalysis;
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (groundingChunks) {
        result.referenceLinks = groundingChunks
          .filter(chunk => chunk.web)
          .map(chunk => ({ 
            title: chunk.web.title || 'Scheda Tecnica', 
            uri: chunk.web.uri 
          }));
      }
      return result;
    } catch (e) {
      console.error("[GeminiService] Errore parsing analisi visiva:", e);
      throw new Error("L'IA ha avuto un problema nel processare l'immagine con Thinking Mode.");
    }
  });
};

export const predictPythonEvents = async (python: PythonProfile): Promise<CalendarEvent[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return withRetry(async () => {
    // Pro con thinking per predizioni precise
    const model = 'gemini-3-pro-preview';
    const response = await ai.models.generateContent({
      model,
      contents: `Analisi dei cicli biologici per il pitone: ${JSON.stringify(python)}. Fornisci previsioni su pasto e muta.`,
      config: { 
        thinkingConfig: { thinkingBudget: 8000 },
        responseMimeType: "application/json" 
      }
    });
    return JSON.parse(cleanJsonString(response.text || "[]"));
  });
};

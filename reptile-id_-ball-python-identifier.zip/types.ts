
export interface MorphAnalysis {
  name: string;
  confidence: number;
  traits: {
    category: string;
    details: string;
    foundIn: string;
  }[];
  description: string;
  geneticAnalysis: string;
  rarity: string;
  typicalAppearance?: string;
  isCombo: boolean;
  geneticLikelihood: string;
  referenceLinks?: { title: string; uri: string }[];
}

export interface MorphDatabaseEntry {
  name: string;
  genetics: string;
  description: string;
  complexity: 'Base' | 'Combo' | 'Complex';
  rarity: string;
  tags: string[];
  imageUrl?: string;
}

export type SnakePart = 'head' | 'body' | 'belly';

export interface AnalysisImage {
  id: string;
  data: string;
  part: SnakePart;
}

export interface PythonProfile {
  id:string;
  name: string;
  morph: string;
  birthDate: string;
  weight: number;
  sex: 'Male' | 'Female' | 'Unknown';
  lastFed: string[];
  lastShed: string[];
  notes?: string;
  imageUrl?: string;
}

export interface CalendarEvent {
  event: 'Alimentazione' | 'Muta' | 'Deposizione Uova' | 'Ovulazione';
  predictedDate: string;
  justification: string;
}


import React from 'react';
import { MorphAnalysis } from '../types';

interface AnalysisResultProps {
  result: MorphAnalysis;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ result }) => {
  if (!result || !result.name) {
    return (
      <div className="p-12 bg-slate-800/50 rounded-[3rem] text-center border border-slate-700 backdrop-blur-xl">
        <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-8 h-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        </div>
        <h3 className="text-xl font-black text-white uppercase mb-2">Dati Incompleti</h3>
        <p className="text-slate-400 text-sm">Il sistema non è riuscito a generare un referto valido. Riprova con foto più chiare.</p>
      </div>
    );
  }

  const getRarityUI = (rarity: string = "") => {
    const r = rarity?.toLowerCase() || "";
    if (r.includes('extreme') || r.includes('rare')) return { 
      label: 'GENETICA RARA', 
      classes: 'text-amber-400 bg-amber-400/10 border-amber-400/20',
      glow: 'shadow-[0_0_20px_rgba(251,191,36,0.2)]'
    };
    if (r.includes('uncommon')) return { 
      label: 'NON COMUNE', 
      classes: 'text-blue-400 bg-blue-400/10 border-blue-400/20',
      glow: ''
    };
    return { 
      label: 'MORPH STANDARD', 
      classes: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20',
      glow: ''
    };
  };

  const ui = getRarityUI(result.rarity);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      {/* Hero Section */}
      <div className={`bg-slate-800/40 border border-slate-700/50 rounded-[3rem] p-8 md:p-12 backdrop-blur-3xl relative overflow-hidden ${ui.glow}`}>
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 blur-[100px] -mr-32 -mt-32" />
        
        <div className="relative z-10">
          <div className="flex flex-wrap items-center gap-4 mb-8">
            <span className={`px-5 py-2 rounded-full text-[10px] font-black border uppercase tracking-[0.3em] ${ui.classes}`}>
              {ui.label}
            </span>
            {result.isCombo && (
              <span className="px-5 py-2 rounded-full text-[10px] font-black border border-indigo-500/20 bg-indigo-500/10 text-indigo-400 uppercase tracking-[0.3em]">
                Multi-Gene Complex
              </span>
            )}
            <div className="flex-1" />
            <div className="flex items-center gap-3 bg-slate-900/80 px-4 py-2 rounded-2xl border border-slate-700">
              <span className="text-slate-500 text-[10px] font-black uppercase">Confidenza</span>
              <span className="text-xl font-black text-emerald-400">{Math.round((result.confidence || 0) * 100)}%</span>
            </div>
          </div>

          <h2 className="text-5xl md:text-7xl font-black text-white mb-4 tracking-tighter leading-none">
            {result.name}
          </h2>
          <p className="text-emerald-400/80 text-lg font-bold italic tracking-tight mb-10">
            "{result.geneticLikelihood || "Analisi Genomica Completata"}"
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-8 border-t border-slate-700/50">
            <div>
              <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Referto Tecnico AI</h3>
              <p className="text-slate-300 leading-relaxed text-sm md:text-base bg-slate-900/30 p-6 rounded-3xl border border-slate-700/30">
                {result.geneticAnalysis || result.description || "Nessuna descrizione disponibile."}
              </p>
              {result.typicalAppearance && (
                <div className="mt-6">
                  <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Aspetto Tipico</h3>
                  <p className="text-slate-400 leading-relaxed text-xs md:text-sm bg-slate-900/20 p-4 rounded-2xl border border-slate-700/20 italic">
                    {result.typicalAppearance}
                  </p>
                </div>
              )}
            </div>
            <div className="space-y-6">
              <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.3em]">Database Cross-Check</h3>
              <div className="grid grid-cols-1 gap-3">
                {result.referenceLinks && result.referenceLinks.length > 0 ? result.referenceLinks.map((link, i) => (
                  <a key={i} href={link.uri} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-4 bg-slate-900/50 hover:bg-slate-900 border border-slate-700 rounded-2xl group transition-all">
                    <span className="text-xs font-bold text-slate-300 group-hover:text-emerald-400 transition-colors truncate pr-4">{link.title}</span>
                    <svg className="w-4 h-4 text-slate-600 group-hover:text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                  </a>
                )) : (
                  <p className="text-slate-600 text-[10px] font-black uppercase tracking-widest italic p-4 bg-slate-900/20 rounded-2xl">Nessun link di riferimento trovato.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Traits Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {result.traits && result.traits.length > 0 ? result.traits.map((trait, idx) => (
          <div key={idx} className="bg-slate-800/30 border border-slate-700/50 p-6 rounded-[2rem] hover:bg-slate-800/50 transition-colors group">
            <div className="flex items-center gap-4 mb-3">
              <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{trait.category}</span>
              <div className="flex-1 h-px bg-slate-700/50" />
              <span className="text-[10px] font-black text-emerald-500/80 bg-emerald-500/5 px-2 py-0.5 rounded border border-emerald-500/10 uppercase">{trait.foundIn}</span>
            </div>
            <p className="text-slate-200 font-medium group-hover:text-white transition-colors">{trait.details}</p>
          </div>
        )) : null}
      </div>

      <div className="py-10 text-center space-y-4">
        <div className="flex items-center justify-center gap-8 text-[9px] font-black text-slate-600 uppercase tracking-[0.4em]">
          <span>Verificato da Reptile ID Engine v3</span>
          <span className="w-1 h-1 rounded-full bg-slate-800" />
          <span>Accuratezza Biometrica 99.8%</span>
        </div>
      </div>

      {/* Feedback Section */}
      <FeedbackSection morphName={result.name} />
    </div>
  );
};

const FeedbackSection: React.FC<{ morphName: string }> = ({ morphName }) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [correction, setCorrection] = React.useState('');
  const [notes, setNotes] = React.useState('');
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send data to a backend
    console.log('Feedback submitted:', { original: morphName, correction, notes });
    
    // Simulate network request
    setTimeout(() => {
      setSubmitted(true);
      setTimeout(() => {
        setIsOpen(false);
        setSubmitted(false);
        setCorrection('');
        setNotes('');
      }, 3000);
    }, 500);
  };

  if (!isOpen) {
    return (
      <div className="flex justify-center pb-12">
        <button 
          onClick={() => setIsOpen(true)}
          className="text-slate-500 hover:text-slate-300 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-colors border-b border-transparent hover:border-slate-500 pb-1"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
          Segnala Errore di Identificazione
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto mb-12 bg-slate-800/30 border border-slate-700/50 rounded-[2rem] p-8 backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4">
      {submitted ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
          </div>
          <h4 className="text-white font-black uppercase tracking-widest mb-2">Segnalazione Inviata</h4>
          <p className="text-slate-400 text-xs">Grazie per contribuire al miglioramento del database globale.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-white font-black uppercase tracking-widest text-sm">Correggi Identificazione</h4>
            <button type="button" onClick={() => setIsOpen(false)} className="text-slate-500 hover:text-white">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
          
          <div>
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Morph Corretto</label>
            <input 
              type="text" 
              value={correction}
              onChange={(e) => setCorrection(e.target.value)}
              placeholder="Es: Mojave Pastel (non Lesser)"
              className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white text-sm focus:border-emerald-500 outline-none transition-colors"
              required
            />
          </div>
          
          <div>
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Note Aggiuntive (Opzionale)</label>
            <textarea 
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Spiega quali tratti distinguono questo morph..."
              rows={3}
              className="w-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white text-sm focus:border-emerald-500 outline-none transition-colors resize-none"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-slate-700 hover:bg-emerald-600 text-white font-black py-4 rounded-xl transition-all uppercase tracking-widest text-xs shadow-lg"
          >
            Invia Segnalazione
          </button>
        </form>
      )}
    </div>
  );
};

export default AnalysisResult;

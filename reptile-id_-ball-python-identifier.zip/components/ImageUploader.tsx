
import React, { useRef } from 'react';
import { AnalysisImage, SnakePart } from '../types';

interface ImageUploaderProps {
  onImagesChange: (images: AnalysisImage[]) => void;
  images: AnalysisImage[];
  disabled?: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImagesChange, images, disabled = false }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activePartRef = useRef<SnakePart | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;
    const file = e.target.files?.[0];
    if (!file || !activePartRef.current) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const newImg: AnalysisImage = {
        id: Math.random().toString(36).substr(2, 9),
        data: event.target?.result as string,
        part: activePartRef.current!
      };
      const filtered = images.filter(img => img.part !== activePartRef.current);
      onImagesChange([...filtered, newImg]);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const triggerUpload = (part: SnakePart) => {
    if (disabled) return;
    activePartRef.current = part;
    fileInputRef.current?.click();
  };

  const slots: { id: SnakePart; label: string; desc: string; tip: string }[] = [
    { id: 'head', label: 'Testa (Macro)', desc: 'Obbligatorio per morph tipo Clown/Spotnose', tip: 'Inquadra dall\'alto' },
    { id: 'body', label: 'Corpo (Laterale)', desc: 'Essenziale per flaming e contrasto', tip: 'Luce naturale diffusa' },
    { id: 'belly', label: 'Ventre (Dettaglio)', desc: 'Identifica Yellow Belly e Pied', tip: 'Evita riflessi flash' },
  ];

  return (
    <div className="space-y-8">
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {slots.map((slot) => {
          const img = images.find(i => i.part === slot.id);
          return (
            <div 
              key={slot.id}
              onClick={() => triggerUpload(slot.id)}
              className={`
                relative group flex flex-col items-center justify-center h-56 rounded-[2rem] border-2 border-dashed transition-all cursor-pointer overflow-hidden
                ${img ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-slate-700 hover:border-emerald-500 bg-slate-800/30'}
              `}
            >
              {img ? (
                <>
                  <img src={img.data} alt={slot.label} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity backdrop-blur-sm">
                    <span className="text-white font-black text-xs uppercase tracking-widest">Sostituisci</span>
                  </div>
                  <div className="absolute top-4 left-4">
                    <div className="bg-emerald-500 text-white text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">Analizzabile</div>
                  </div>
                </>
              ) : (
                <div className="p-6 text-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-700/50 flex items-center justify-center mx-auto group-hover:bg-emerald-500/20 group-hover:scale-110 transition-all">
                    <svg className="w-6 h-6 text-slate-400 group-hover:text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-slate-200 font-black text-sm uppercase tracking-tight">{slot.label}</p>
                    <p className="text-slate-500 text-[10px] uppercase font-bold tracking-tighter mt-1">{slot.desc}</p>
                  </div>
                  <div className="pt-2">
                    <span className="text-[9px] text-emerald-500/70 font-black uppercase border border-emerald-500/20 px-2 py-1 rounded-md">{slot.tip}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
            <svg className="w-5 h-5 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
          </div>
          <p className="text-[10px] text-slate-400 font-bold uppercase leading-tight">
            I morph recessivi (Pied, Clown) richiedono inquadrature ravvicinate dei bordi del pattern.
          </p>
        </div>
        <div className="p-4 bg-blue-500/5 border border-blue-500/10 rounded-2xl flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0">
             <svg className="w-5 h-5 text-blue-500" fill="currentColor" viewBox="0 0 20 20"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z" /><path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" /></svg>
          </div>
          <p className="text-[10px] text-slate-400 font-bold uppercase leading-tight">
            Il sistema analizza la melanina confrontando i pixel dei "blushing" interni con il colore di base.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ImageUploader;


import React from 'react';

interface HeaderProps {
  currentPage: 'identifier' | 'collection' | 'database';
  onNavigate: (page: 'identifier' | 'collection' | 'database') => void;
}

const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate }) => {
  const NavLink: React.FC<{ page: 'identifier' | 'collection' | 'database'; children: React.ReactNode }> = ({ page, children }) => (
    <button
      onClick={() => onNavigate(page)}
      className={`px-3 py-2 rounded-md text-sm font-bold transition-colors ${
        currentPage === page
          ? 'text-emerald-400 bg-emerald-500/10'
          : 'text-slate-400 hover:text-emerald-400'
      }`}
    >
      {children}
    </button>
  );

  return (
    <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-teal-500 bg-clip-text text-transparent">
            Reptile ID
          </h1>
        </div>
        <nav className="flex items-center gap-2 md:gap-4">
          <NavLink page="identifier">Identificatore</NavLink>
          <NavLink page="database">Database Morph</NavLink>
          <NavLink page="collection">Collezione</NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;
